new Vue({
  el: "#app",

  data: {
    stok: stok,
    upbjjList: upbjjList,
    kategoriList: kategoriList,

    filterUpbjj: "",
    filterKategori: "",
    filterMenipis: false,
    filterKosong: false,
    sortBy: "",

    editMode: false,
    editItem: {},

    baru: {
      kode: "",
      judul: "",
      kategori: "",
      upbjj: "",
      lokasiRak: "",
      qty: null,
      safety: null,
      harga: null,
      catatanHTML: ""
    }
  },

  computed: {
    hasilFilter() {
      let data = [...this.stok];

      if (this.filterUpbjj) {
        data = data.filter(d => d.upbjj === this.filterUpbjj);
      }

      if (this.filterKategori) {
        data = data.filter(d => d.kategori === this.filterKategori);
      }

      if (this.filterMenipis) {
        data = data.filter(d => d.qty < d.safety && d.qty > 0);
      }

      if (this.filterKosong) {
        data = data.filter(d => d.qty === 0);
      }

      if (this.sortBy === "judul")
        data.sort((a, b) => a.judul.localeCompare(b.judul));
      if (this.sortBy === "qty")
        data.sort((a, b) => a.qty - b.qty);
      if (this.sortBy === "harga")
        data.sort((a, b) => a.harga - b.harga);

      return data;
    }
  },

  methods: {
    resetFilter() {
      this.filterUpbjj = "";
      this.filterKategori = "";
      this.filterMenipis = false;
      this.filterKosong = false;
      this.sortBy = "";
    },

    mulaiEdit(item) {
      this.editMode = true;
      this.editItem = item;
    },

    simpanEdit() {
      alert("Data berhasil diperbarui.");
      this.editMode = false;
    },

    batalEdit() {
      this.editMode = false;
    },

    tambahBaru() {
      const b = this.baru;

      if (!b.kode || !b.judul || !b.kategori || !b.upbjj ||
          !b.lokasiRak || b.qty === null || b.safety === null || b.harga === null) {
        alert("Semua field harus diisi.");
        return;
      }

      this.stok.push({...b});
      alert("Data berhasil ditambahkan.");

      this.baru = {
        kode: "",
        judul: "",
        kategori: "",
        upbjj: "",
        lokasiRak: "",
        qty: null,
        safety: null,
        harga: null,
        catatanHTML: ""
      };
    }
  },

  watch: {
    filterUpbjj() {
      this.filterKategori = "";
    },

    sortBy(v) {
      console.log("Sorting by:", v);
    }
  }
});

new Vue({
  el: "#app",

  data: {
    pengirimanList: pengirimanList,
    paket: paket,
    tracking: tracking,

    baru: {
      nim: "",
      nama: "",
      ekspedisi: "",
      paket: "",
      tanggalKirim: ""
    }
  },

  computed: {
    nextDO() {
      const year = new Date().getFullYear();
      const keys = Object.keys(this.tracking).sort();
      if (keys.length === 0) return `DO${year}-001`;

      const lastKey = keys[keys.length - 1]; // DO2025-00X
      const lastNum = parseInt(lastKey.split("-")[1], 10) || 0;
      const nextNum = lastNum + 1;

      return `DO${year}-${String(nextNum).padStart(3, "0")}`;
    },

    detailPaket() {
      return this.paket.find(p => p.kode === this.baru.paket);
    }
  },

  methods: {
    formatRupiah(val) {
      return "Rp " + Number(val).toLocaleString("id-ID");
    },

    buatDO() {
      if (!this.baru.nim || !this.baru.nama ||
          !this.baru.ekspedisi || !this.baru.paket) {
        alert("Semua field utama (NIM, Nama, Ekspedisi, Paket) wajib diisi.");
        return;
      }

      const harga = this.detailPaket ? this.detailPaket.harga : 0;
      const today = new Date().toISOString().slice(0, 10);

      this.$set(this.tracking, this.nextDO, {
        nim: this.baru.nim,
        nama: this.baru.nama,
        ekspedisi: this.baru.ekspedisi,
        paket: this.baru.paket,
        tanggalKirim: this.baru.tanggalKirim || today,
        total: harga
      });

      alert("Delivery Order baru berhasil disimpan.");

      this.baru = {
        nim: "",
        nama: "",
        ekspedisi: "",
        paket: "",
        tanggalKirim: ""
      };
    }
  },

  watch: {
    "baru.paket"(val) {
      console.log("Paket dipilih:", val);
    },
    "baru.tanggalKirim"(val) {
      console.log("Tanggal kirim diubah:", val);
    }
  }
});

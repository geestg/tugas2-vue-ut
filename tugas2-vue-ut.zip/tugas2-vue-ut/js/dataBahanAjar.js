const upbjjList = ["Jakarta", "Surabaya", "Makassar", "Padang", "Medan"];
const kategoriList = ["MK Wajib", "MK Pilihan", "Praktikum"];

const stok = [
  {
    kode: "EKMA4116",
    judul: "Pengantar Manajemen",
    kategori: "MK Wajib",
    upbjj: "Jakarta",
    lokasiRak: "RAK 1A",
    qty: 25,
    safety: 10,
    harga: 60000,
    catatanHTML: "<em>Edisi Baru 2024</em>"
  },
  {
    kode: "BIOL4201",
    judul: "Biologi Umum",
    kategori: "MK Wajib",
    upbjj: "Surabaya",
    lokasiRak: "RAK 2B",
    qty: 5,
    safety: 10,
    harga: 55000,
    catatanHTML: "<b>Menipis</b>"
  },
  {
    kode: "EKMA4117",
    judul: "Pengantar Akuntansi",
    kategori: "MK Wajib",
    upbjj: "Makassar",
    lokasiRak: "RAK 3A",
    qty: 0,
    safety: 8,
    harga: 65000,
    catatanHTML: "Segera Re-Order"
  }
];

const pengirimanList = [
  { kode: "REG", nama: "JNE Regular" },
  { kode: "EXP", nama: "JNE Express" }
];

const paket = [
  {
    kode: "PAKET-01",
    nama: "PAKET EKONOMI",
    isi: ["EKMA4116", "EKMA4117"],
    harga: 120000
  },
  {
    kode: "PAKET-02",
    nama: "PAKET IPA",
    isi: ["BIOL4201"],
    harga: 55000
  }
];

const tracking = {};

new Vue({
  el: "#app",

  data: {
    stok: stok,
    upbjjList: upbjjList,
    kategoriList: kategoriList,

    filterUpbjj: "",
    filterKategori: "",
    filterMenipis: false,
    filterKosong: false,
    sortBy: "",

    sedangEdit: null,

    editData: {
      qty: null,
      lokasiRak: "",
      catatanHTML: ""
    },

    baru: {
      kode: "",
      judul: "",
      kategori: "",
      upbjj: "",
      lokasiRak: "",
      qty: null,
      safety: null,
      harga: null,
      catatanHTML: ""
    }
  },

  computed: {
    hasilFilter() {
      let data = [...this.stok];

      if (this.filterUpbjj)
        data = data.filter(i => i.upbjj === this.filterUpbjj);

      if (this.filterKategori)
        data = data.filter(i => i.kategori === this.filterKategori);

      if (this.filterMenipis)
        data = data.filter(i => i.qty < i.safety && i.qty > 0);

      if (this.filterKosong)
        data = data.filter(i => i.qty === 0);

      if (this.sortBy === "judul")
        data.sort((a, b) => a.judul.localeCompare(b.judul));

      if (this.sortBy === "qty")
        data.sort((a, b) => a.qty - b.qty);

      if (this.sortBy === "harga")
        data.sort((a, b) => a.harga - b.harga);

      return data;
    }
  },

  methods: {
    resetFilter() {
      this.filterUpbjj = "";
      this.filterKategori = "";
      this.filterMenipis = false;
      this.filterKosong = false;
      this.sortBy = "";
    },

    mulaiEdit(index) {
      this.sedangEdit = index;

      const item = this.stok[index];
      this.editData = {
        qty: item.qty,
        lokasiRak: item.lokasiRak,
        catatanHTML: item.catatanHTML
      };
    },

    simpanEdit() {
      const item = this.stok[this.sedangEdit];

      item.qty = this.editData.qty;
      item.lokasiRak = this.editData.lokasiRak;
      item.catatanHTML = this.editData.catatanHTML;

      alert("Data berhasil diperbarui");
      this.sedangEdit = null;
    },

    batalkanEdit() {
      this.sedangEdit = null;
    },

    tambahBaru() {
      if (
        !this.baru.kode ||
        !this.baru.judul ||
        !this.baru.kategori ||
        !this.baru.upbjj
      ) {
        alert("Semua field wajib diisi!");
        return;
      }

      this.stok.push({ ...this.baru });

      alert("Data baru ditambahkan");

      this.baru = {
        kode: "",
        judul: "",
        kategori: "",
        upbjj: "",
        lokasiRak: "",
        qty: null,
        safety: null,
        harga: null,
        catatanHTML: ""
      };
    }
  }
});

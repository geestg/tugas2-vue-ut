new Vue({
  el: "#app",

  data: {
    pengirimanList: pengirimanList,
    paket: paket,
    tracking: tracking,

    baru: {
      nim: "",
      nama: "",
      ekspedisi: "",
      paket: "",
      tanggalKirim: ""
    }
  },

  computed: {
    nextDO() {
      const year = new Date().getFullYear();
      const list = Object.keys(this.tracking);

      if (list.length === 0) return `DO${year}-001`;

      const last = list[list.length - 1];
      const number = parseInt(last.split("-")[1]) + 1;

      return `DO${year}-${String(number).padStart(3, "0")}`;
    },

    detailPaket() {
      return this.paket.find(p => p.kode === this.baru.paket);
    }
  },

  methods: {
    buatDO() {
      if (!this.baru.nim || !this.baru.nama ||
          !this.baru.ekspedisi || !this.baru.paket) {
        alert("Semua field harus diisi.");
        return;
      }

      const harga = this.detailPaket.harga;

      this.$set(this.tracking, this.nextDO, {
        nim: this.baru.nim,
        nama: this.baru.nama,
        ekspedisi: this.baru.ekspedisi,
        paket: this.baru.paket,
        tanggalKirim: this.baru.tanggalKirim || new Date().toISOString().slice(0, 10),
        total: harga,
        status: "Diproses",
        perjalanan: []
      });

      alert("DO berhasil dibuat!");

      this.baru = {
        nim: "",
        nama: "",
        ekspedisi: "",
        paket: "",
        tanggalKirim: ""
      };
    }
  },

  watch: {
    "baru.paket"(val) {
      console.log("Paket dipilih:", val);
    },

    "baru.tanggalKirim"(val) {
      console.log("Tanggal dipilih:", val);
    }
  }
});
